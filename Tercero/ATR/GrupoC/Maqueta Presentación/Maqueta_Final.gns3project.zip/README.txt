Project: 'Maqueta' created on 2022-10-07
Author: John Doe <john.doe@example.com>

No project description was given